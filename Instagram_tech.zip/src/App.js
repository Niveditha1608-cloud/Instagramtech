import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Sidebar from './Components/Sidebar';
import './App.css';
import Header from './Components/Header';
import Feed from './Components/Feed';


function App() {
  return (
    <Router>
    <div className="App">
        <Sidebar/>
      <div className="main-content">
        <Header/>
       <div className="main">
        <Feed/>
       </div>
      </div>
      </div>
      </Router>
  );
};

export default App;


