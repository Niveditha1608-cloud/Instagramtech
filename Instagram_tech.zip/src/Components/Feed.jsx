import React, { useState, useEffect } from "react";
import axios from "axios";
import'./Feed.css';
import likeIcon from '../assets/icons/heart.png';
import commentIcon from '../assets/icons/chat.png';

const Feed = () => {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3001/posts').then((response) => {setPosts(response.data); 

        })
        .catch((error) => {console.error('Error fetching the posts:',error);
    });
}, []);
const handleLike = async(id) => {
    const updatedPosts = posts.map(post =>{
        if(post.id === id){
            return {...post,likes:post.likes+1};
        }
        return post;
        });

    setPosts(updatedPosts);

    try{
        await axios.patch(`http://localhost:3001/posts/${id}`,{
            likes:updatedPosts.find(post => post.id === id).likes,
        });
        axios.get('http://localhost:3001/posts')
        .then((response) => {
            setPosts(response.data);
        })

        // localStorage.setItem('posts',JSON.stringify(updatedPhotos));
    }
    catch (error) {
        console.error('Error liking post',error);
    }
};

return(
    <div className="Feed-container">
        <div className="feed-title">
            <h2>Feed</h2>
        </div>
        <div className="feed-list">
            {posts.map(post => (
                <div className="post"  key={post.id} >
                <img src={post.imageUrl} alt={ posts } className="post-image"/>
                <div className="post-info">
                <img src={post.avatar} alt={posts} className="post-avatar"/>
                    <p className="post-username">{post.username}</p>
                    </div>
                <div className="post-icons">
                    <img src={likeIcon} alt="like" className="icon" onClick={() => handleLike(post.id)}/>
                    <span>{post.likes}</span>
                    <img src={commentIcon} alt="comment" className="icon" onClick={() => console.log("Coment button Clicked")}/>
                    <span>{post.comment}Comments</span>
               
                </div>
                </div>
                
            ))}
        </div>
        </div>
);
};

export default Feed;