import React from 'react';
import { NavLink } from 'react-router-dom';
import './Header.css';
const Header = () => {

    const stories = [
       {id: 1, img:'https://randomuser.me/api/portraits/women/30.jpg'},
       {id: 2, img:'https://randomuser.me/api/portraits/women/31.jpg'},
       {id: 3, img:'https://randomuser.me/api/portraits/women/32.jpg'},
       {id: 4, img:'https://randomuser.me/api/portraits/women/33.jpg'},
       {id: 5, img:'https://randomuser.me/api/portraits/women/34.jpg'},
       {id: 6, img:'https://randomuser.me/api/portraits/women/35.jpg'},
       {id: 7, img:'https://randomuser.me/api/portraits/women/36.jpg'},
       {id: 8, img:'https://randomuser.me/api/portraits/women/37.jpg'},
       {id: 9, img:'https://randomuser.me/api/portraits/men/9.jpg'},
       {id: 10, img:'https://randomuser.me/api/portraits/women/10.jpg'},
       {id: 11, img: "https://randomuser.me/api/portraits/women/30.jpg" },
       {id: 12, img: "https://randomuser.me/api/portraits/women/31.jpg" },
       {id: 13, img: "https://randomuser.me/api/portraits/women/32.jpg" },
       {id: 14, img: "https://randomuser.me/api/portraits/women/33.jpg" },
       {id: 15, img: "https://randomuser.me/api/portraits/women/34.jpg" },

    ];

    return(
        <div className="header-container">
            <header className="header">
                <div className="header-right">
                    <input type="text" className="search-bar" placeholder="Search"/>
                </div>
            </header>
        <div className="stories-section">
            <h2>Stories</h2>
            <div className="stories-list">
                {stories.map((story) => (
                    <NavLink to={'/story'} className="story-link" key={story.id}>
                        <div className="story" key={story.id}>
                            <img src={story.img} alt={story} className="story-image" />
                        </div>
                        </NavLink>
                ))}
            </div>
        </div>
        </div>
    );
};

export default Header;