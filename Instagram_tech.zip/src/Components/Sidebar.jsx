import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import './Sidebar.css';

//Import the icon images
import feedIcon from '../assets/icons/feed-icon.png';
import friendsIcon from '../assets/icons/friends-icon.png';
import eventsIcon from '../assets/icons/events-icon.png';
import videosIcon from '../assets/icons/videos-icon.png';
import photosIcon from '../assets/icons/photos-icon.png';
import notificationsIcon from '../assets/icons/notification-icon.png';
import settingsIcon from '../assets/icons/settings-icon.png';
import logoutIcon from '../assets/icons/logout-icon.png';

function Sidebar() {
    const [activeItem, setActiveItem] = useState(null);


const handleclick = (item) => {
    setActiveItem(item);
};

    return (
       <div className="sidebar">
        <div className="profile">
          <div classname="profile-border">
            <img src="https://randomuser.me/api/portraits/women/13.jpg" alt="Profile" className="profile-img"/>
       </div>
       <h3 className="profile-name">Aanya Chalotra</h3>
       <p className="profile-username">@aanya345</p>
       </div>
       <div classname="menu">
        <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li classname={activeItem === 'feed' ? 'active' : ''}>
                <NavLink to="/feed" onClick={() => handleclick('feed')} className={({isActive}) => (isActive ? 'active' : '')}>
                <img src={feedIcon} alt="Feed Icon" className="menu-icon"/>Feed
                </NavLink>
            </li>
        </ul>
        <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li>
                <img src={friendsIcon} alt="Friends Icon" className="menu-icon"/>Friends
            </li>
            </ul>
            <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li>
                <img src={eventsIcon} alt="Events Icon" className="menu-icon"/>Events
                
            </li>
            </ul>
            <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li>
                <img src={videosIcon} alt="Videos Icon" className="menu-icon"/>Videos   
            </li>
            </ul>
            <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li>
                <img src={photosIcon} alt="Photos Icon" className="menu-icon"/>Photos
            </li>
            </ul>
            <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li>
                <img src={notificationsIcon} alt="Notifications Icon" className="menu-icon"/>Notifications
            </li>
            </ul>
            <ul style={{listStyleType: 'none', padding: 8, margin: 20}}>
            <li >
                <img src={settingsIcon} alt="Settings Icon" className="menu-icon"/>Settings
            </li>
        </ul>
       </div>
       <div className="logout">
        <img src={logoutIcon} alt="Logout Icon" className="menu-icon"/>Log out
       </div>
       </div>
        
    );
}

export default Sidebar;